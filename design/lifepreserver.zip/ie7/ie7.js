/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'lifepreserver\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-directions': '&#xe900;',
		'icon-mail': '&#xe605;',
		'icon-vcard': '&#xe901;',
		'icon-export': '&#xe606;',
		'icon-compass': '&#xe902;',
		'icon-target': '&#xe903;',
		'icon-share': '&#xe904;',
		'icon-heart': '&#xe607;',
		'icon-heart2': '&#xe905;',
		'icon-star': '&#xe608;',
		'icon-star2': '&#xe906;',
		'icon-chat': '&#xe609;',
		'icon-comment': '&#xe60a;',
		'icon-popup': '&#xe907;',
		'icon-search': '&#xe60b;',
		'icon-link': '&#xe908;',
		'icon-cog': '&#xe909;',
		'icon-megaphone': '&#xe90a;',
		'icon-graduation': '&#xe60c;',
		'icon-book': '&#xe60d;',
		'icon-newspaper': '&#xe90b;',
		'icon-eye': '&#xe90c;',
		'icon-clock': '&#xe90d;',
		'icon-microphone': '&#xe90e;',
		'icon-calendar': '&#xe90f;',
		'icon-bolt': '&#xe910;',
		'icon-thunder': '&#xe911;',
		'icon-rocket': '&#xe912;',
		'icon-code': '&#xe913;',
		'icon-light-bulb': '&#xe60e;',
		'icon-rss': '&#xe600;',
		'icon-signal': '&#xe60f;',
		'icon-info': '&#xe610;',
		'icon-help': '&#xe611;',
		'icon-warning': '&#xe914;',
		'icon-text': '&#xe915;',
		'icon-text2': '&#xe916;',
		'icon-install': '&#xe917;',
		'icon-cloud': '&#xe612;',
		'icon-upload': '&#xe918;',
		'icon-book2': '&#xe919;',
		'icon-stop': '&#xe613;',
		'icon-resize-enlarge': '&#xe91a;',
		'icon-resize-shrink': '&#xe91b;',
		'icon-flow-cascade': '&#xe91c;',
		'icon-flow-branch': '&#xe91d;',
		'icon-flow-tree': '&#xe91e;',
		'icon-flow-line': '&#xe91f;',
		'icon-flow-parallel': '&#xe920;',
		'icon-cc': '&#xe614;',
		'icon-cc-by': '&#xe615;',
		'icon-cc-nc': '&#xe616;',
		'icon-cc-sa': '&#xe617;',
		'icon-cc-nd': '&#xe618;',
		'icon-cc-pd': '&#xe619;',
		'icon-cc-zero': '&#xe61a;',
		'icon-cc-share': '&#xe61e;',
		'icon-cc-share2': '&#xe61f;',
		'icon-github2': '&#xe921;',
		'icon-github': '&#xe61b;',
		'icon-twitter': '&#xe601;',
		'icon-facebook': '&#xe602;',
		'icon-googleplus': '&#xe603;',
		'icon-pinterest': '&#xe61c;',
		'icon-linkedin': '&#xe604;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
